<?php
    $conn = mysqli_connect('localhost', 'root', '', 'student_cell');
    // $conn = mysqli_connect("148.66.137.19", "x36jcq2f1oc5","NandI@123","student_cell");
?>

