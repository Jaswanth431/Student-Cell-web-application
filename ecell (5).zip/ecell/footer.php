
<footer>
    <div class="footer-left">
        Copyright &copy; RGUKT ONGOLE
    </div>
    <div class="footer-right">
        <i class="fa fa-user" aria-hidden="true"></i>
            Developed by Web Team RGUKT ONGOLE
    </div>
</footer>