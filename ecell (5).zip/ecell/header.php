<header>
            <div class="header-left-box">
                <div class="logo-box">
                    <img src="img/rgukt.png" alt="logo" />
                </div>
                <h1>RGUKT-ONGOLE STUDENT CELL</h1>
            </div>
            <div class="header-right-box">
                
                <ul class="header-ul-list">
                    <li>
                        <a href="http://rguktong.ac.in" target="_blank"
                            ><i class="fa fa-home" aria-hidden="true"></i> Home
                        </a>
                    </li>
                    <li>
                        <a href="#">Contact Us <i class="fa fa-chevron-circle-down" aria-hidden="true"></i></a>
                        <div class="contact-info">
                            <p><i class="fa fa-envelope" aria-hidden="true"></i> Email: test@rgutong.ac.in</p>
                            <p><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7981771744</p>
                        </div>
                    </li>
                </ul>
                
            </div>
            <div class="toggle-icon">
                    <i class="fa fa-bars" aria-hidden="true"></i>
            </div>
 </header>