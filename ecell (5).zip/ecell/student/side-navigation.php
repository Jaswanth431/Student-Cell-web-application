   <ul class="navigation-list">
   <li class="navigation-items"><a href="home.php" class="navigation-links active"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
      <li class="navigation-items"><a href="get-result.php" class="navigation-links"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
   Results</a></li>
      <li class="navigation-items"><a href="faculty-survey.php" class="navigation-links"><i class="fa fa-list-alt" aria-hidden="true"></i>
   Survey</a></li>
      <li class="navigation-items"><a href="profile.php" class="navigation-links"><i class="fa fa-user" aria-hidden="true"></i>
   Profile</a></li>
      <li class="navigation-items"><a href="#" class="navigation-links"><i class="fa fa-registered" aria-hidden="true"></i>
   Registrations</a></li>
   <li class="navigation-items"><a href="complaint.php" class="navigation-links"><i class="fa fa-comment" aria-hidden="true"></i>
   Complaint</a></li>
      <li class="navigation-items"><a href="outpass.php" class="navigation-links">
      <i class="fa fa-forward" aria-hidden="true"></i> Outpass</a></li>
   <li class="navigation-items"><a href="reset-password.php" class="navigation-links">
      <i class="fa fa-key" aria-hidden="true"></i> Reset Password</a></li>

     
   <li class="navigation-items"><a href="../includes/logout.inc.php" class="navigation-links"><i class="fa fa-sign-out" aria-hidden="true"></i>
   Logout</a></li>
  </ul>